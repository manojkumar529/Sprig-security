package com.example.akeneo;
import org.springframework.web.bind.annotation.*;
@RestController
@RequestMapping("/products")
public class ProductController {
  @GetMapping
  public String getProducts(){ return "{ \"mock\": true }"; }
}
