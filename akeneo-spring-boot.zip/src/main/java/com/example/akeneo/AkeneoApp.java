package com.example.akeneo;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class AkeneoApp {
  public static void main(String[] args){SpringApplication.run(AkeneoApp.class,args);}
}
