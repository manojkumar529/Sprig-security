package com.example.hazard.service.impl;

import com.example.hazard.dto.*;
import com.example.hazard.entity.*;
import com.example.hazard.repository.HazardProductRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.OffsetDateTime;
import java.util.*;

@Service
@Transactional
public class HazardServiceImpl implements HazardService {

    private final HazardProductRepository repository;
    private final ObjectMapper mapper = new ObjectMapper();

    public HazardServiceImpl(HazardProductRepository repository) {
        this.repository = repository;
    }

    @Override
    public HazardResponse create(HazardRequest request) {

        HazardProduct product = new HazardProduct();
        product.setUuid(request.getUuid());
        product.setEnabled(request.getEnabled());
        product.setFamily(request.getFamily());
        product.setCategories(request.getCategories());
        product.setCreated(OffsetDateTime.now());
        product.setUpdated(OffsetDateTime.now());

        request.getValues().forEach((attrName, list) -> {
            for (HazardValueRequest v : list) {
                HazardAttributeValue av = new HazardAttributeValue();
                av.setAttributeName(attrName);
                av.setLocale(v.getLocale());
                av.setScope(v.getScope());
                av.setAttributeType(v.getAttribute_type());

                try {
                    av.setData(mapper.writeValueAsString(v.getData()));
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }

                av.setProduct(product);
                product.getValues().add(av);
            }
        });

        HazardProduct saved = repository.save(product);
       return  buildFullResponse(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public HazardResponse getByUuid(String uuid) {

        HazardProduct product = repository.findByUuidWithValues(uuid)
                .orElseThrow(() -> new RuntimeException("Hazard not found"));

        Map<String, List<HazardValueResponse>> valuesMap = new LinkedHashMap<>();

        for (HazardAttributeValue v : product.getValues()) {

            HazardValueResponse resp = new HazardValueResponse();
            resp.setLocale(v.getLocale());
            resp.setScope(v.getScope());
            resp.setAttribute_type(v.getAttributeType());

            try {
                resp.setData(
                    mapper.readValue(v.getData(), Object.class)
                );
            } catch (Exception e) {
                resp.setData(v.getData());
            }

            valuesMap
                .computeIfAbsent(v.getAttributeName(),
                        k -> new ArrayList<>())
                .add(resp);
        }

        HazardResponse response = new HazardResponse();
        response.setUuid(product.getUuid());
        response.setEnabled(product.getEnabled());
        response.setFamily(product.getFamily());
        response.setCategories(product.getCategories());
        response.setValues(valuesMap);
        response.setCreated(product.getCreated());
        response.setUpdated(product.getUpdated());

        return response;
    }
    private HazardResponse buildFullResponse(HazardProduct product) {

        Map<String, List<HazardValueResponse>> valuesMap = new LinkedHashMap<>();

        for (HazardAttributeValue v : product.getValues()) {

            HazardValueResponse resp = new HazardValueResponse();
            resp.setLocale(v.getLocale());
            resp.setScope(v.getScope());
            resp.setAttribute_type(v.getAttributeType());

            try {
                resp.setData(mapper.readValue(v.getData(), Object.class));
            } catch (Exception e) {
                resp.setData(v.getData());
            }

            valuesMap
                .computeIfAbsent(v.getAttributeName(),
                        k -> new ArrayList<>())
                .add(resp);
        }

        HazardResponse response = new HazardResponse();
        response.setUuid(product.getUuid());
        response.setEnabled(product.getEnabled());
        response.setFamily(product.getFamily());
        response.setCategories(product.getCategories());
        response.setValues(valuesMap);
        response.setCreated(product.getCreated());
        response.setUpdated(product.getUpdated());

        return response;
    }
    @Override
    @Transactional(readOnly = true)
    public List<HazardResponse> getAll() {

        List<HazardProduct> products =
                repository.findAllWithValues();

        List<HazardResponse> responseList = new ArrayList<>();

        for (HazardProduct product : products) {
            responseList.add(buildFullResponse(product));
        }

        return responseList;
    }


}
