
package com.example.hazard.entity;

import lombok.*;
import javax.persistence.*;

@Entity
@Table(name = "hazard_attribute_value")
@Getter @Setter
public class HazardAttributeValue {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String attributeName;
    private String locale;
    private String scope;
    private String attributeType;

    @Lob
    @Column(columnDefinition = "TEXT")
    private String data;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "product_id")
    private HazardProduct product;
}
