
package com.example.hazard.dto;

import lombok.*;
import java.util.*;

@Getter @Setter
public class HazardRequest {
    private String uuid;
    private Boolean enabled;
    private String family;
    private List<String> categories;
    private Map<String, List<HazardValueRequest>> values;
}
