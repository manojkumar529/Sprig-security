
package com.example.hazard.dto;

import lombok.*;

@Getter @Setter
public class HazardValueRequest {
    private String locale;
    private String scope;
    private Object data;
    private String attribute_type;
}
