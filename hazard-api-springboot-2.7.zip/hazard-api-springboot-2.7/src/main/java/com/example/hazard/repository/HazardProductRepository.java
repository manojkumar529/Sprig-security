
package com.example.hazard.repository;

import com.example.hazard.entity.HazardProduct;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface HazardProductRepository extends JpaRepository<HazardProduct, Long> {

    @Query(
        "SELECT p FROM HazardProduct p " +
        "LEFT JOIN FETCH p.values " +
        "WHERE p.uuid = :uuid"
    )
    Optional<HazardProduct> findByUuidWithValues(@Param("uuid") String uuid);
	@Query("SELECT DISTINCT p FROM HazardProduct p\n"
			+ "    		LEFT JOIN FETCH p.values"
	    )
    		List<HazardProduct> findAllWithValues();
    		
    	
}
