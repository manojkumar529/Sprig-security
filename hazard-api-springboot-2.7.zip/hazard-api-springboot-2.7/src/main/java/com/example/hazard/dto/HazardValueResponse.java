package com.example.hazard.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class HazardValueResponse {
	private String locale;
    private String scope;
    private Object data;
    private String attribute_type;
}