
package com.example.hazard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HazardApiApplication {
    public static void main(String[] args) {
        SpringApplication.run(HazardApiApplication.class, args);
    }
}
