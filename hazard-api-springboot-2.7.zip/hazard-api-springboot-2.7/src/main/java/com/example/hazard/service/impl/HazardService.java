package com.example.hazard.service.impl;

import java.util.List;

import com.example.hazard.dto.HazardRequest;
import com.example.hazard.dto.HazardResponse;

public interface HazardService {
	HazardResponse create(HazardRequest request);
	List<HazardResponse> getAll();

	    HazardResponse getByUuid(String uuid);
}
