
package com.example.hazard.controller;

import com.example.hazard.dto.*;
import com.example.hazard.service.impl.HazardService;

import java.util.List;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/hazards")
public class HazardController {

	private final HazardService service;

	public HazardController(HazardService service) {
		this.service = service;
	}

	@PostMapping
	public HazardResponse create(@RequestBody HazardRequest request) {
		return service.create(request);
	}

	@GetMapping("/{uuid}")
	public HazardResponse getByUuid(@PathVariable String uuid) {
		return service.getByUuid(uuid);
	}
	@GetMapping
	public List<HazardResponse> getAll() {
	    return service.getAll();
	}

}
