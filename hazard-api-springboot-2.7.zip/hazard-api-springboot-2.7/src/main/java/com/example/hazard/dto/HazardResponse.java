
package com.example.hazard.dto;

import lombok.*;

import java.time.OffsetDateTime;
import java.util.*;

@Getter @Setter
public class HazardResponse {
	private String uuid;
    private Boolean enabled;
    private String family;
    private List<String> categories;

    private Map<String, List<HazardValueResponse>> values;

    private OffsetDateTime created;
    private OffsetDateTime updated;
}
