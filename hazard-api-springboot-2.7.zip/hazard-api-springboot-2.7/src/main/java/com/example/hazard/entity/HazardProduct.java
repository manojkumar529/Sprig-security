
package com.example.hazard.entity;

import lombok.*;
import javax.persistence.*;
import java.time.OffsetDateTime;
import java.util.*;

@Entity
@Table(name = "hazard_product")
@Getter @Setter
public class HazardProduct {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String uuid;
    private Boolean enabled;
    private String family;

    @ElementCollection
    @CollectionTable(name = "hazard_categories", joinColumns = @JoinColumn(name = "product_id"))
    @Column(name = "category")
    private List<String> categories;

    private OffsetDateTime created;
    private OffsetDateTime updated;

    @OneToMany(mappedBy = "product", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<HazardAttributeValue> values = new ArrayList<>();
}
