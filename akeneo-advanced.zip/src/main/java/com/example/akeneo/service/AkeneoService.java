package com.example.akeneo.service;

import com.example.akeneo.dto.AccessTokenResponse;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

@Service
public class AkeneoService {

    private final WebClient client;

    public AkeneoService(WebClient client){ this.client=client; }

    @Value("${akeneo.url}") private String url;
    @Value("${akeneo.client_id}") private String clientId;
    @Value("${akeneo.secret}") private String secret;
    @Value("${akeneo.username}") private String username;
    @Value("${akeneo.password}") private String password;

    private AccessTokenResponse cachedToken;

    private AccessTokenResponse fetchToken() {
        return client.post()
                .uri(url + "/api/oauth/v1/token")
                .headers(h->h.setBasicAuth(clientId, secret))
                .bodyValue("grant_type=password&username="+username+"&password="+password)
                .retrieve()
                .bodyToMono(AccessTokenResponse.class)
                .block();
    }

    private AccessTokenResponse refreshToken(){
        return client.post()
                .uri(url + "/api/oauth/v1/token")
                .headers(h->h.setBasicAuth(clientId, secret))
                .bodyValue("grant_type=refresh_token&refresh_token="+cachedToken.refresh_token)
                .retrieve()
                .bodyToMono(AccessTokenResponse.class)
                .block();
    }

    private String getValidToken(){
        if(cachedToken==null) cachedToken=fetchToken();
        return cachedToken.access_token;
    }

    public String getProducts(int page){
        return client.get()
                .uri(url + "/api/rest/v1/products?page="+page+"&limit=10&pagination_type=page")
                .headers(h->h.setBearerAuth(getValidToken()))
                .retrieve()
                .bodyToMono(String.class)
                .block();
    }

    public String createProduct(String json){
        return client.post()
                .uri(url + "/api/rest/v1/products")
                .headers(h->h.setBearerAuth(getValidToken()))
                .bodyValue(json)
                .retrieve()
                .bodyToMono(String.class)
                .block();
    }

    public String uploadMedia(String filename){
        return "{ "mock_media_upload": ""+filename+""}";
    }
}
