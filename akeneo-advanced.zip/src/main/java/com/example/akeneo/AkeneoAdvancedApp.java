package com.example.akeneo;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.SpringApplication;

@SpringBootApplication
public class AkeneoAdvancedApp {
  public static void main(String[] args){SpringApplication.run(AkeneoAdvancedApp.class,args);}
}
