package com.example.akeneo.controller;

import com.example.akeneo.service.AkeneoService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/akeneo")
public class AkeneoController {

    private final AkeneoService service;
    public AkeneoController(AkeneoService service){this.service=service;}

    @GetMapping("/products")
    public String getProducts(@RequestParam(defaultValue="1") int page){
        return service.getProducts(page);
    }

    @PostMapping("/products")
    public String createProduct(@RequestBody String json){
        return service.createProduct(json);
    }

    @PostMapping("/media")
    public String uploadMedia(@RequestParam String filename){
        return service.uploadMedia(filename);
    }
}
