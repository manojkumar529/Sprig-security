package com.example.akeneo.dto;

public class AccessTokenResponse {
    public String access_token;
    public String refresh_token;
    public int expires_in;
    public String token_type;
}
